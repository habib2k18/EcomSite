<!--Right side bar-->
<div class="col-md-2" id="rightbarcss">
  <?php
    include 'widgets/cart.php';
    include 'widgets/recent.php';
  ?>

</div>
