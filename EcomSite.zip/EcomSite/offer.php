<?php
require_once 'core/init.php';

$offerResults = $db->query("SELECT * FROM offers");
$offer = mysqli_fetch_assoc($offerResults);
$offerCount = mysqli_num_rows($offerResults);
?>

<!-- offer -->
<?php if($offerCount > 0): ?>
  <div class="offer-wrap">
    <div class="offer-inner">
      <h1 class="text-center"><b><?=$offer['offerdes'];?></b></h1>
      <a href="offerindex.php" class="btn btn-default offer-btn" tabindex="0">Shop Now</a>
    </div>
  </div>
<?php endif; ?>
