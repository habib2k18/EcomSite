<?php
//require_once '../core/init.php';
include "config.php";
include "ratinghead.php"

//postid == productid
?>



        <script type="text/javascript">
        $(function() {
            $('.rating').barrating({
                theme: 'fontawesome-stars',
                onSelect: function(value, text, event) {

                    // Get element id by data-id attribute
                    var el = this;
                    var el_id = el.$elem.data('id');

                    // rating was selected by a user
                    if (typeof(event) !== 'undefined') {

                        var split_id = el_id.split("_");

                        var postid = split_id[1];  // postid

                        // AJAX Request
                        $.ajax({
                            url: 'rating_ajax.php',
                            type: 'post',
                            data: {postid:postid,rating:value},
                            dataType: 'json',
                            success: function(data){
                                // Update average
                                var average = data['averageRating'];
                                $('#avgrating_'+postid).text(average);
                            }
                        });
                    }
                }
            });
        });

        </script>

        <div class="content">

            <?php
                //$userid = $user_id_user;
                //echo $user_id_user; die();
                /*$query = "SELECT * FROM posts";
                $result = mysqli_query($con,$query);
                while($row = mysqli_fetch_array($result)){
                     $postid = $row['id'];
                    /*$title = $row['title'];
                    $content = $row['content'];
                    $link = $row['link'];*/

                    // User rating
                    $postid = "15";
                    $query = "SELECT * FROM ratings WHERE product_id='$postid'";
                    $userresult = $con->query($query);
                    $fetchRating = mysqli_fetch_assoc($userresult);
                    $rating = $fetchRating['rating'];

                    // get average
                    $query = "SELECT ROUND(AVG(rating),1) as averageRating FROM ratings WHERE product_id='$postid'";
                    $avgresult = $con->query($query);
                    $fetchAverage = mysqli_fetch_assoc($avgresult);
                    $averageRating = $fetchAverage['averageRating'];

                    if($averageRating <= 0){
                        $averageRating = "No rating yet.";
                    }
            ?>
                    <div class="post">

                        <div class="post-action">
                            <!-- Rating -->
                            <select class='rating' id='rating_<?php echo $postid; ?>' data-id='rating_<?php echo $postid; ?>'>
                                <option value="1" >1</option>
                                <option value="2" >2</option>
                                <option value="3" >3</option>
                                <option value="4" >4</option>
                                <option value="5" >5</option>
                            </select>
                            <div style='clear: both;'></div>
                            Average Rating : <span id='avgrating_<?php echo $postid; ?>'><?php echo $averageRating; ?></span>

                            <!-- Set rating -->
                            <script type='text/javascript'>
                            $(document).ready(function(){
                                $('#rating_<?php echo $postid; ?>').barrating('set',<?php echo $rating; ?>);
                            });

                            </script>
                        </div>
                    </div>


        </div>
