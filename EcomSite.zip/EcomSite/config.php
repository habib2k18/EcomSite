<?php
define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/EcomSite/');
define('CART_COOKIE', 'SBinzuhabib28pm');
define('CART_COOKIE_EXPIRE', time() + (86400 *1));
define('TAXRATE', 0.02);

define('CURRENCY', 'usd');
define('CHECKOUTMODE', 'TEST');

if(CHECKOUTMODE == 'TEST'){
  define('STRIPE_PUBLIC', 'pk_test_fsgMTfxzhmB5V5aqSsN2sCrM');
  define('STRIPE_PRIVATE', 'sk_test_rWEyqsl7PolzsBRYIa56a76e');
}
