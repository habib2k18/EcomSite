<?/*/php
session_start();

$name = "";
$email = "";
$password = "";
$confirm = "";
$mobile = "";
$errors = array();
$db = mysqli_connect('localhost', 'root', '', 'ecomsite');

if(isset($_POST['register'])){
  $name = mysql_real_escape_string($_POST['name']);
  $email = mysql_real_escape_string($_POST['email']);
  $password = mysql_real_escape_string($_POST['password']);
  $confirm = mysql_real_escape_string($_POST['confirm']);
  $mobile = mysql_real_escape_string($_POST['mobile']);

  $emailQuery = $db->query("select * from users where email = '$email'");
  $emailCount = mysqli_num_rows($emailQuery);

  if($emailCount != 0){
      $errors[] = 'That email already exits';
  }

  if($password != $confirm){
    $errors[] = "The two passwords do not match";
  }

  if(empty($errors)){
    $password = md5($password);
    $sql = "INSERT INTO users (full_name, email, password) VALUES
    ('$name', '$email', '$password')";
    mysqli_query($db, $sql);
    header('Location: index.php');
  }
}

?>*/
