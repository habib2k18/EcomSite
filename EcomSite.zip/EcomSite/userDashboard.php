<?php
    require_once 'core/init.php';
    include 'includes/head.php';
    include 'includes/navigation.php';
    include 'includes/headerimage.php';

    $sql = "select * from users where id='$user_id_user'";
    $userQ = $db->query($sql);
    $user = mysqli_fetch_assoc($userQ);

    $sql = "select * from transactions where user_id='$user_id_user'";
    $orderHistoryQ = $db->query($sql);
    //$orderHistory = mysqli_fetch_assoc($orderHistoryQ);
    //$orderHistoryCount = mysqli_num_rows($orderHistoryQ); echo $orderHistoryCount; die();
?>

    <div class="container">
      <div class="row">
        <div class="col-md-12">
            <h1 class="text-center"><b><?= $user['full_name'];?></b><br>
            <h5><b>Email:</b> <?= $user['email']; ?> </h5>
            <h5><b>Contact No:</b> <?= $user['mobile']; ?> </h5>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-center">Order History</h1>

          <table class="table table-striped">
            <thead>
              <th>Product List</th>
              <th>Price</th>
              <th>Date</th>
            </thead>

            <tbody>
              <?php while ($orderHistory = mysqli_fetch_assoc($orderHistoryQ)): ?>
              <tr>

                <td>
                    <?php
                        $orderCart_id = $orderHistory['cart_id'];
                        $sql = "select * from cart where id = '$orderCart_id'";
                        $itemsFromCartQ = $db->query($sql);
                        $itemsFromCart = mysqli_fetch_assoc($itemsFromCartQ);
                          $items = json_decode($itemsFromCart['items'], true);
                          foreach($items as $item){
                            $product_id = $item['id'];
                            $productQ = $db->query("SELECT * FROM products WHERE id = '{$product_id}'");
                            $product = mysqli_fetch_assoc($productQ);
                            echo "<strong>".'Name: '."</strong>".$product['title']."<strong>".' Size: '."</strong>".$item['size']."<strong>".' Quantity: '."</strong>".$item['quantity']; echo "<br>";
                          }
                    ?>

                </td>

                <td> ৳ <?= $orderHistory['grand_total']; ?> </td>
                <td>  <?= pretty_date($orderHistory['txn_date']); ?> </td>
              </tr>
            <?php endwhile; ?>
            </tbody>
          </table>

        </div>
      </div>
    </div>

<?php
    include 'includes/footer.php';
?>
