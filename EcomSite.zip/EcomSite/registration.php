<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/EcomSite/core/init.php';

include 'includes/head.php';

$name = "";
$email = "";
$password = "";
$confirm = "";
$mobile = "";
$errors = array();

if(isset($_POST['register'])){
  $name = mysql_real_escape_string($_POST['name']);
  $email = mysql_real_escape_string($_POST['email']);
  $password = mysql_real_escape_string($_POST['password']);
  $confirm = mysql_real_escape_string($_POST['confirm']);
  $mobile = mysql_real_escape_string($_POST['mobile']);

  $emailQuery = $db->query("select * from users where email = '$email'");
  $emailCount = mysqli_num_rows($emailQuery);

  if($emailCount != 0){
      $errors[] = 'That email already exits';
  }

  if($password != $confirm){
    $errors[] = "The two passwords do not match";
  }

  if(empty($errors)){
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (full_name, email, password, mobile) VALUES
    ('$name', '$email', '$hashed', '$mobile')";
    mysqli_query($db, $sql);
    header('Location: signin.php');
  }
}

?>

<style>
    body{
        background-image: url("/EcomSite/images/headerlogo/background.png");
        background-size: 100w 100w;
        background-attachment: fixed;
    }
</style>

<div id="login-form">
    <h2 class="text-center">Sign Up</h2><hr>
    <form action="registration.php" method="post">
      <?php
        if(!empty($errors)){
            echo display_errors($errors);
        }
      ?>
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="name" name="name" id="name" class="form-control" value="<?=$name;?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" class="form-control" value="<?=$email;?>" required>
        </div>
        <div class="form-group">
            <label for="mobile">Contact No</label>
            <input type="text" name="mobile" id="mobile" class="form-control" value="<?=$mobile;?>" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" class="form-control" value="" required>
        </div>
        <div class="form-group">
            <label for="confirm">Confirm Password</label>
            <input type="password" name="confirm" id="confirm" class="form-control" value="" required>
        </div>
        <div class="form-group">
            <input type="submit" name="register" value="signup" class="btn btn-primary">
        </div>
    </form>
    <p class="text-right"><a href="/EcomSite/signin.php" alt="home">have an account?</a></p>
</div>


<?php include 'includes/footer.php'; ?>
