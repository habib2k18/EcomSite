<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/EcomSite/core/init.php';
unset($_SESSION['SBUser2']);

unset($_COOKIE[CART_COOKIE]);
setcookie('SBinzuhabib28pm', "", time()-7200, "/");

header('Location: signin.php');
?>
