<?php
  require_once 'core/init.php';

  \Stripe\Stripe::setApiKey(STRIPE_PRIVATE);

  // trying to send sms..

    $to = $_POST['mobile'];
    $token = "6d9eab9f58701c2569b914e880b84485";
    $message = 'Successfully Received Your Order! Your order id is '.$_POST['cart_id'];

    $url =  "http://sms.greenweb.com.bd/api.php";

    $data = array(
      'to' => "$to",
      'message' => "$message",
      'token'=> "$token"
      );
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $smsresult = curl_exec($ch);

  // sms close

  //get the credit card details submitted by the form
  $userid = $user_id_user;
  $token = $_POST['stripeToken'];
  //get the rest of the post data
  $full_name = sanitize($_POST['full_name']);
  $email = sanitize($_POST['email']);
  $street = sanitize($_POST['street']);
  $city = sanitize($_POST['city']);
  $division = sanitize($_POST['division']);
  $zip_code = sanitize($_POST['zip_code']);
  $mobile = sanitize($_POST['mobile']);
  $tax = sanitize($_POST['tax']);
  $sub_total = sanitize($_POST['sub_total']);
  $grand_total = sanitize($_POST['grand_total']);
  $cart_id = sanitize($_POST['cart_id']);
  $description = sanitize($_POST['description']);
  $charge_amount = number_format($grand_total, 2) * 100;
  $metadata = array(
    "cart_id" => $cart_id,
    "tax" => $tax,
    "sub_total" => $sub_total,
  );


  //create the charge on Stripe's server - this will charge the user's Card
  try{
    $charge = \Stripe\Charge::create(array(
      "amount" => $charge_amount, //paisa
      "currency" => CURRENCY,
      "source" => $token,
      "description" => $description,
      "receipt_email" => $email,
      "metadata" => $metadata)
    );


  //adjust inventory
  $itemQ = $db->query("SELECT * FROM cart WHERE id='{$cart_id}'");
  $iresults = mysqli_fetch_assoc($itemQ);
  $items = json_decode($iresults['items'], true);
  foreach($items as $item){
    $newSizes = array();
    $item_id = $item['id'];
    $productQ = $db->query("SELECT sizes FROM products WHERE id = '{$item_id}'");
    $product = mysqli_fetch_assoc($productQ);
    $sizes = sizesToArray($product['sizes']);
    foreach($sizes as $size){
      if($size['size'] == $item['size']){
        $q = $size['quantity'] - $item['quantity'];
        $newSizes[] = array('size' => $size['size'], 'quantity' => $q);
      }else{
        $newSizes[] = array('size' => $size['size'], 'quantity' => $size['quantity']);
      }
    }
    $sizeString = sizesToString($newSizes);
    $db->query("UPDATE products SET sizes = '{$sizeString}' WHERE id = '{$item_id}' ");
  }

  //update cart
  $db->query("UPDATE cart SET paid = 1 WHERE id = '{$cart_id}'");
  $db->query("INSERT INTO transactions
    (charge_id, cart_id, full_name, email, street, city, division, zip_code, mobile, sub_total, tax, grand_total, description, txn_type, user_id) VALUES
    ('$charge->id', '$cart_id', '$full_name', '$email', '$street', '$city', '$division', '$zip_code', '$mobile', '$sub_total', '$tax', '$grand_total', '$description', '$charge->object', '$userid')");
  $domain = ($_SERVER['HTTP_HOST'] != 'localhost')? '.'.$_SERVER['HTTP_HOST']: false;
  setcookie(CART_COOKIE, '', 1, "/", $domain, false);
  include 'includes/head.php';
  include 'includes/navigation.php';
  include 'includes/headerpartial.php';
  ?>
    <h1 class="text-center text-success"> Thank You! </h1>
    <p>Your cart has been successfully charged <?=money($grand_total) ;?>. </p>
    <p>Your reciept number is <strong><?=$cart_id;?></strong> </p>
    <p>Your order will be shipped to the address below.</p>
    <address>
      Name: <?=$full_name ;?><br>
      Street: <?=$street ;?><br>
      City: <?=$city;?><br>
      Division: <?=$division; ?><br>
      Postal Code: <?=$zip_code; ?><br>
      Mobile: <?=$mobile;?><br>
    </address>
  <?php
  include 'includes/footer.php';
  }catch(\Stripe\Error\Card $e){
    echo $e;
  }
?>
